package friends2;

public class Friends2 {

    public static void main(String[] args) {
        MainForm frm = new MainForm();
        frm.setVisible(true);
        
    }
    
}